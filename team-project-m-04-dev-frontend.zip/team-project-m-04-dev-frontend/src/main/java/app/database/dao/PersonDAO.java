package app.database.dao;

import app.database.Database;
import app.database.dao.DAOWhereBuilder.Comparison;
import app.model.Person;

import java.sql.*;
import java.util.*;

public class PersonDAO extends DAO
{
	public PersonDAO(Database database) throws SQLException
	{
		super(database);
		setTable("person");
	}

	public Iterable<Person> getAllShows() throws SQLException
	{
		List<Person> people = new ArrayList<>();

		table.absolute(0);
		while(table.next())
		{
			people.add((Person)generateObjectFromResultSet(table));
		}
		table.absolute(0);

		return people;
	}

	/**
	 * How to write wildcards with mysql: https://www.mysqltutorial.org/mysql-like/
	 * @param pattern the pattern that a person's name needs to match to be returned.
	 * @return
	 */
	public Iterable<Person> getPeopleMatchingName(String pattern) throws SQLException
	{
		List<Person> people = new ArrayList<>();

		ResultSet rs = query(new String[] { "*" }, new DAOWhereBuilder("fullname", pattern, Comparison.Like));
		while(rs.next())
		{
			people.add((Person)generateObjectFromResultSet(rs));
		}

		return people;
	}

	@Override
	protected Object generateObjectFromResultSet(ResultSet rs) throws SQLException
	{
		return new Person (
			DAOUtils.getInteger(rs, "person_id"),
			rs.getString("fullname"),
			rs.getString("role"),
			rs.getDate("birthdate"),
			rs.getString("bio")
		);
	}
}