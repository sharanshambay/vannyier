package app;

import app.model.*;

import java.sql.SQLException;
import io.javalin.*;
import io.javalin.core.util.RouteOverviewPlugin;
import static io.javalin.apibuilder.ApiBuilder.*;

import app.controller.IndexController;
import app.controller.SearchController;
import app.database.*;
import app.database.dao.*;

public class Main
{
    public static Database database;
    public static AccountDAO accountDao;
	public static UserDAO userDao;
	public static ProCoDAO proCoDao;
	public static ShowDAO showDao;
	public static PersonDAO personDao;
    public static final int javalinPort = 7000;

    public static void main(String[] args)
    {
		try
		{
			database = new Database("imdb");
			// If database couldn't connect, don't bother loading all the dao.
			if(database.isConnected())
			{
				try
				{
					userDao = new UserDAO(database);
					proCoDao = new ProCoDAO(database);
					accountDao = new AccountDAO(database, userDao, proCoDao);
					showDao = new ShowDAO(database, proCoDao);
					personDao = new PersonDAO(database);
				}
				catch(SQLException e)
				{
					e.printStackTrace();
				}
			}
	
			Javalin app = Javalin.create(config ->
			{
				config.addStaticFiles("/public");
				config.registerPlugin(new RouteOverviewPlugin("/routes"));
			})
			.start(javalinPort)
			.get("/", IndexController.serveIndexPage);
	
			app.routes(() ->
			{
				get("/index", IndexController.serveIndexPage);
				get("/search", SearchController.handleSearchGet);
			});
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
    }

}
