package app.model;

import java.util.Date;

public class Person
{
	private Integer id;
	private String fullName;
	private String role;
	private Date birthDate;
	private String bio;

	public Person(Integer id, String fullName, String role, Date birthDate, String bio)
	{
		this.id = id;
		this.fullName = fullName;
		this.role = role;
		this.birthDate = birthDate;
		this.bio = bio;
	}

	public Integer getId() { return id; }

	public String getFullName() { return fullName; }

	public String getRole() { return role; }

	public Date getBirthDate() { return birthDate; }

	public String getBio() { return bio; }

	@Override
	public String toString() {
		return String.format("Person (id: %d, name: %s, role: %s, birthdate: %s, bio: %s)", id, fullName, role, birthDate, bio);
	}
}
