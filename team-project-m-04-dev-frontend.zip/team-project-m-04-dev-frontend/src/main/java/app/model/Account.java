package app.model;

public class Account
{
    protected String username;
    protected String password;
    protected String email;
    protected String country;
	protected boolean bIsAdmin;
	protected User user;
	protected ProCo proCo;

    public Account(String username, String password, String email, String country, boolean bIsAdmin, User user)
    {
        this.username = username;
        this.password = password;
        this.email = email;
        this.country = country;
		this.bIsAdmin = bIsAdmin;
		this.user = user;
		this.proCo = null;
    }

    public Account(String username, String password, String email, String country, ProCo proCo)
    {
        this.username = username;
        this.password = password;
        this.email = email;
        this.country = country;
		this.bIsAdmin = false;
		this.proCo = proCo;
		this.user = null;
    }

    public String getUsername()
    {
        return username;
    }

    public String getPassword()
    {
        return password;
    }

    public String getEmail()
    {
        return email;
    }

	public String getCountry()
	{
		return country;
	}

	public boolean isAdmin()
	{
		return bIsAdmin;
	}

	public boolean isProductionCompany()
	{
		return proCo != null;
	}

	public User getUser()
	{
		return user;
	}

	public ProCo getProCo()
	{
		return proCo;
	}

	@Override
	public String toString()
	{
		return String.format("Account (username: %s, password: %s, email: %s, country: %s, admin: %s, type: %s)", username, password, email, country, bIsAdmin, isProductionCompany() ? proCo.toString() : user.toString());
	}
}