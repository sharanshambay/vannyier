package app.database.dao;

import app.model.*;
import app.database.Database;

import java.sql.*;

public class ProCoDAO extends DAO
{
	public ProCoDAO(Database database) throws SQLException
	{
		super(database);
		setTable("production_company");
	}

	public ProCo getProCoById(int id) throws SQLException
	{
		ResultSet rs = query(new String[] { "*" }, new DAOWhereBuilder("proco_id", id));
		if(rs.next())
		{
			return (ProCo)generateObjectFromResultSet(rs);
		}
		return null;
	}

	public int insertProCo(ProCo proCo) throws SQLException
	{
		return insert(proCo.getId(), proCo.getCompanyName());
	}

	public int deleteProCo(ProCo proCo) throws SQLException
	{
		return deleteProCoByID(proCo.getId());
	}

	public int deleteProCoByID(int id) throws SQLException
	{
		return delete(new DAOWhereBuilder("proco_id", id));
	}

	@Override
	protected Object generateObjectFromResultSet(ResultSet rs) throws SQLException
	{
		Integer proCoId = DAOUtils.getInteger(rs, "proco_id");
		String companyName = rs.getString("proco_name");
		return new ProCo(proCoId, companyName);
	}
}
