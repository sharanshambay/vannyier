package app.controller;

import io.javalin.http.Handler;
import static app.Main.*;
import app.controller.paths.HTMLPages;
import java.util.*;

public class IndexController
{
	public static Handler serveIndexPage = ctx ->
	{
		Map<String, Object> map = new HashMap<>();
		ctx.render(HTMLPages.INDEX, map);
	};
}
