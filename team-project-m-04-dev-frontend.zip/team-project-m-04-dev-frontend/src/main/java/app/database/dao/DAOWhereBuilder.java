package app.database.dao;

public class DAOWhereBuilder
{
	private StringBuilder text;

	public enum Comparison
	{
		Equals,
		Is,
		Like,
		NotEquals,
		IsNot,
		NotLike
	}

	public DAOWhereBuilder(String columnName, Object value)
	{
		text = new StringBuilder();
		addCondition(columnName, value, Comparison.Equals);
	}

	public DAOWhereBuilder(String columnName, Object value, Comparison comparison)
	{
		text = new StringBuilder();
		addCondition(columnName, value, comparison);
	}

	private void addCondition(String columnName, Object value, Comparison comparison)
	{
		String comparisonString;
		switch(comparison)
		{
			case Equals:
				comparisonString = "=";
				break;
			case Is:
				comparisonString = "IS";
				break;
			case Like:
				comparisonString = "LIKE";
				break;
			case NotEquals:
				comparisonString = "<>";
				break;
			case IsNot:
				comparisonString = "IS NOT";
				break;
			case NotLike:
				comparisonString = "NOT LIKE";
				break;
			default:
				comparisonString = "=";
				break;
		}
		text.append(String.format("%s %s %s", columnName, comparisonString, DAOUtils.valueToString(value)));
	}

	public DAOWhereBuilder and(String columnName, Object value)
	{
		text.append(" AND ");
		addCondition(columnName, value, Comparison.Equals);
		return this;
	}

	public DAOWhereBuilder and(String columnName, Object value, Comparison comparison)
	{
		text.append(" AND ");
		addCondition(columnName, value, comparison);
		return this;
	}

	public DAOWhereBuilder or(String columnName, Object value)
	{
		text.append(" OR ");
		addCondition(columnName, value, Comparison.Equals);
		return this;
	}

	public DAOWhereBuilder or(String columnName, Object value, Comparison comparison)
	{
		text.append(" OR ");
		addCondition(columnName, value, comparison);
		return this;
	}

	public String getText()
	{
		return text.toString();
	}
}