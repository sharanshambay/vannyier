package app.database.dao;

import app.database.Database;
import app.model.Gender;
import app.model.User;

import java.sql.*;

public class UserDAO extends DAO
{
	public UserDAO(Database database) throws SQLException
	{
		super(database);
		setTable("user");
	}

	public int insertUser(User user) throws SQLException
	{
		return insert(user.getId(), user.getFirstName(), user.getLastName(), user.getGender().toString());
	}

	public int deleteUser(User user) throws SQLException
	{
		return deleteUserByID(user.getId());
	}

	public int deleteUserByID(int id) throws SQLException
	{
		return delete(new DAOWhereBuilder("user_id", id));
	}

	@Override
	protected Object generateObjectFromResultSet(ResultSet rs) throws SQLException
	{
		Integer userId = DAOUtils.getInteger(rs, "user_id");
		String firstName = rs.getString("first_name");
		String lastName = rs.getString("last_name");
		Gender gender = rs.getString("gender").equals("M") ? Gender.MALE : Gender.FEMALE;
		return new User(userId, gender, firstName, lastName);
	}
}