package app.model;

public class Admin extends User {
    private boolean admin;

    public Admin() {

    }

    public void setAdmin() {
        this.admin = !this.admin;
    }

    public boolean getAdmin() {
        return this.admin;
    }

    public void acceptRegistration() {

    }

}
