package app.model;

public class User
{
	private Integer id;
    private String firstName;
    private String lastName;
    private Gender gender;

    public User(Integer id, Gender gender, String firstName, String lastName)
    {
		this.id = id;
        this.gender = gender;
        this.firstName = firstName;
        this.lastName = lastName;
    }

    public String getFirstName()
    {
        return firstName;
    }

    public String getLastName()
    {
        return lastName;
    }

    public Gender getGender()
    {
        return gender;
    }

	public Integer getId()
	{
		return id;
	}

	@Override
	public String toString()
	{
		return String.format("User (id: %d, first name: %s, last name: %s, gender: %s)", id, firstName, lastName, gender);
	}
}