package app.model;

public class Critic {

    public Critic() {

    }
}
