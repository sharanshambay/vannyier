package app.database.dao;

import app.database.Database;
import app.model.*;

import java.sql.*;
import java.util.*;

import javax.sql.rowset.RowSetProvider;

public class AccountDAO extends DAO
{
	private static final String USERNAME = "username";
	private static final String PASSWORD = "password";
	private static final String COUNTRY = "country";
	private static final String EMAIL = "email";
	private static final String USER_ID = "user_id";
	private static final String PROCO_ID = "proco_id";
	private static final String IS_ADMIN = "is_admin";
	private static final String FIRST_NAME = "first_name";
	private static final String LAST_NAME = "last_name";
	private static final String GENDER = "gender";
	private static final String PROCO_NAME = "proco_name";

	private UserDAO userDao;
	private ProCoDAO proCoDao;

	public AccountDAO(Database database, UserDAO userDao, ProCoDAO proCoDao) throws SQLException
	{
		super(database);
		setTable("account");
		this.userDao = userDao;
		this.proCoDao = proCoDao;
	}

	public Iterable<Account> getAllAccounts() throws SQLException
	{
		List<Account> accounts = new ArrayList<>();

		ResultSet rs = query(new String[] {"*"});
		rs.absolute(0);
		while(rs.next())
		{
			accounts.add((Account)generateObjectFromResultSet(rs));
		}
		rs.absolute(0);	// Reset cursor for next use.

		return accounts;
	}

	public Account getAccountByUsername(String username) throws SQLException
	{
		ResultSet rs = query(new String[] { "*" }, new DAOWhereBuilder(USERNAME, username));
		if(rs.next())
		{
			return (Account)generateObjectFromResultSet(rs);
		}
		return null;
	}

	public int insertAccount(Account account) throws SQLException
	{
		ResultSet rsWithSameUsername = query(new String[] { USERNAME }, new DAOWhereBuilder(USERNAME, account.getUsername()));
		// There is another account with the same username
		if(rsWithSameUsername.next())
		{
			System.err.println(String.format("Another account exists with the username \'%s\'", account.getUsername()));
			return 0;
		}

		Integer userId = null;
		Integer proCoId = null;

		ResultSet generatedKeyRs = null;
		if(account.isProductionCompany())
		{
			proCoDao.insertProCo(account.getProCo());
			generatedKeyRs = proCoDao.getGeneratedKeys();
		}
		else
		{
			userDao.insertUser(account.getUser());
			generatedKeyRs = userDao.getGeneratedKeys();
		}
		
		if(generatedKeyRs.next())
		{
			if(account.isProductionCompany())
			{
				proCoId = generatedKeyRs.getInt(1);
			}
			else
			{
				userId = generatedKeyRs.getInt(1);
			}
		}

		return insert(account.getUsername(), account.getPassword(), account.getEmail(), account.getCountry(), account.isAdmin(), userId, proCoId);
	}

	public int deleteAccountByUsername(String username) throws SQLException
	{
		ResultSet accountRs = query(new String[] { "*" }, new DAOWhereBuilder(USERNAME, username));
		if(!accountRs.next())
		{
			return 0;
		}

		Integer userId = DAOUtils.getInteger(accountRs, USER_ID);
		Integer proCoId = DAOUtils.getInteger(accountRs, PROCO_ID);
		if(userId == null && proCoId == null)
		{
			return 0;
		}
		
		accountRs.deleteRow();

		boolean isProductionCompany = proCoId != null;
		if(isProductionCompany)
		{
			proCoDao.deleteProCoByID(proCoId);
		}
		else
		{
			userDao.deleteUserByID(userId);
		}

		return 1;
	}

	public int deleteAccount(Account account) throws SQLException
	{
		return deleteAccountByUsername(account.getUsername());
	}

	@Override
	protected Object generateObjectFromResultSet(ResultSet rs) throws SQLException
	{
		String username = rs.getString(USERNAME);
		String password = rs.getString(PASSWORD);
		String email = rs.getString(EMAIL);
		String country = rs.getString(COUNTRY);
		boolean isAdmin = rs.getBoolean(IS_ADMIN);
		
		Integer userId = DAOUtils.getInteger(rs, USER_ID);
		Integer proCoId = DAOUtils.getInteger(rs, PROCO_ID);
		if(userId != null)
		{
			ResultSet userRs = userDao.query(new String[] { "*" }, new DAOWhereBuilder(USER_ID, userId));
			if(userRs.next())
			{
				return new Account(username, password, email, country, isAdmin, (User)userDao.generateObjectFromResultSet(userRs));
			}
		}
		else if(proCoId != null)
		{
			ResultSet proCoRs = proCoDao.query(new String[] { "*" }, new DAOWhereBuilder(PROCO_ID, proCoId));
			if(proCoRs.next())
			{
				return new Account(username, password, email, country, (ProCo)proCoDao.generateObjectFromResultSet(proCoRs));
			}
		}

		return null;
	}
}