package app.model;

public class ProCo
{
    private Integer id;
    private String companyName;

	/**
	 * Constructor
	 * 
	 * @param id can be null, in which case will be automatically chosen by MySQL when inserting.
	 * @param companyName
	 */
	public ProCo(Integer id, String companyName)
	{
		this.id = id;
		this.companyName = companyName;
	}

	public String getCompanyName()
	{
		return companyName;
	}

	public Integer getId()
	{
		return id;
	}

	@Override
	public String toString()
	{
		return String.format("ProCo (id: %d, company name: %s)", id, companyName);
	}
}
