package app.controller.paths;

public class HTMLRefs
{
	private static final String INDEX = "/index";
}
