package app.model;

/**
 * Intended for use with only model and database stuff, specifically SQL.
 */
public enum Gender
{
	MALE("M"),
	FEMALE("F");

	private String label;

	private Gender(String label)
	{
		this.label = label;
	}

	@Override
	public String toString()
	{
		return label;
	}
}