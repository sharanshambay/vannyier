package app.controller;

import io.javalin.http.Handler;
import static app.Main.*;
import app.controller.paths.HTMLPages;
import java.util.*;

public class SearchController
{
	public static Handler handleSearchGet = ctx ->
	{
		Map<String, Object> map = new HashMap<>();
		String search = ctx.queryParam("search");
		if(database.isConnected() && !search.equals(""))
		{
			map.put("search", search);
			map.put("people", personDao.getPeopleMatchingName(String.format("%%%s%%", search)));
			map.put("shows", showDao.getShowsMatchingTitle(String.format("%%%s%%", search)));
		}
		ctx.render(HTMLPages.SEARCH, map);
	};
}