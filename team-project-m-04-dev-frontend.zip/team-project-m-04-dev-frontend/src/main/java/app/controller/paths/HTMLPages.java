package app.controller.paths;

public class HTMLPages
{
	public static final String INDEX = "/velocity/index/index.vm";
	public static final String SEARCH = "/velocity/search/search.vm";
}