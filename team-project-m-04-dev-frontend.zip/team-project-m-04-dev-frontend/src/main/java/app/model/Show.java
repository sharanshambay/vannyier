package app.model;

public class Show
{
	private Integer id;
	private String title;
	private Genre genre;
	private double length;
	private ProCo proCompany;
	private int year;

	public Show(Integer id, String title, Genre genre, double length, ProCo proCompany, int year)
	{
		this.id = id;
		this.title = title;
		this.genre = genre;
		this.length = length;
		this.proCompany = proCompany;
		this.year = year;
	}

	public int getId() { return id; }
	
	public String getTitle() { return title; }

	public Genre getGenre() { return genre; }

	public double getLength() { return length; }
	
	public ProCo getProCompany() { return proCompany; }

	public int getYear() { return year; }

	@Override
	public String toString() 
	{
		return String.format("Show (id: %s, title: %s, genre: %s, length: %f, production company: %s, year: %d)", id, title, genre, length, proCompany, year);
	}
}