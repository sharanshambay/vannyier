package app.database.dao;

import app.database.Database;
import app.database.dao.DAOWhereBuilder.Comparison;
import app.model.Genre;
import app.model.ProCo;
import app.model.Show;

import java.sql.*;
import java.util.*;

public class ShowDAO extends DAO
{
	private ProCoDAO proCoDao;

	public ShowDAO(Database database, ProCoDAO proCoDao) throws SQLException
	{
		super(database);
		setTable("show");
		this.proCoDao = proCoDao;
	}

	public Iterable<Show> getAllShows() throws SQLException
	{
		List<Show> shows = new ArrayList<>();

		table.absolute(0);
		while(table.next())
		{
			shows.add((Show)generateObjectFromResultSet(table));
		}
		table.absolute(0);

		return shows;
	}

	/**
	 * How to write wildcards with mysql: https://www.mysqltutorial.org/mysql-like/
	 * @param pattern the pattern that a show's title needs to match to be returned.
	 * @return
	 */
	public Iterable<Show> getShowsMatchingTitle(String pattern) throws SQLException
	{
		List<Show> shows = new ArrayList<>();

		ResultSet rs = query(new String[] { "*" }, new DAOWhereBuilder("show_title", pattern, Comparison.Like));
		while(rs.next())
		{
			shows.add((Show)generateObjectFromResultSet(rs));
		}

		return shows;
	}

	@Override
	protected Object generateObjectFromResultSet(ResultSet rs) throws SQLException
	{
		Integer showId = DAOUtils.getInteger(rs, "show_id");
		String title = rs.getString("show_title");
		Genre genre = Genre.valueOf(rs.getString("genre"));
		double length = rs.getDouble("length");
		ProCo proCo = proCoDao.getProCoById(rs.getInt("proco_id"));
		int year = rs.getInt("year");
		return new Show(showId, title, genre, length, proCo, year);
	}
	
}
