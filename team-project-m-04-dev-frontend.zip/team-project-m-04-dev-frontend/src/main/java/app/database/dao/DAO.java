package app.database.dao;

import app.database.Database;
import java.sql.*;

public abstract class DAO
{
	protected Statement statement;
	protected ResultSet table;
	protected String tableName;

	public DAO(Database database) throws SQLException
	{
		statement = database.createStatement();
		table = null;
	}

	protected void setTable(String tableName) throws SQLException
	{
		if(statement == null)
		{
			System.err.println("Where the fuck is the database");
			return;
		}
		this.tableName = tableName;
		table = query(new String[] { "*" });
	}

	protected ResultSet query(String[] columnsToShow) throws SQLException
	{
		return query(columnsToShow, null);
	}

	protected ResultSet query(String[] columnsToShow, DAOWhereBuilder where) throws SQLException
	{
		if(!canPerformOp(tableName))
		{
			return null;
		}
		if(columnsToShow.length == 0)
		{
			System.err.println("Must have at least one lement in columnsToShow[]");
			return null;
		}
		
		String columnsString = columnsToShow[0];
		for(int i = 1; i < columnsToShow.length; i++)
		{
			columnsString.concat(", " + columnsToShow[i]);
		}
		
		StringBuilder sqlCode = new StringBuilder(String.format("SELECT %s FROM `%s`", columnsString, tableName));
		if(where != null)
		{
			sqlCode.append(" WHERE ").append(where.getText());
		}
		sqlCode.append(';');

		return statement.executeQuery(sqlCode.toString());
	}

	protected int update(String[] columnsToUpdate, Object[] values) throws SQLException
	{
		return update(columnsToUpdate, values, null);
	}

	protected int update(String[] columnsToUpdate, Object[] values, DAOWhereBuilder where) throws SQLException
	{
		if(!canPerformOp(tableName))
		{
			return 0;
		}
		if(columnsToUpdate.length == 0 || columnsToUpdate.length != values.length)
		{
			System.err.println("Must have at least one lement in columnsToShow[]");
			return 0;
		}

		StringBuilder setString = new StringBuilder();
		setString.append(String.format("%s=%s", columnsToUpdate[0], values[0]));
		for(int i = 1; i < columnsToUpdate.length; i++)
		{
			setString.append(',').append(String.format("%s=%s", columnsToUpdate[i], values[i]));
		}

		StringBuilder sqlCode = new StringBuilder(String.format("UPDATE `%s` SET %s", tableName, setString.toString()));
		if(where != null)
		{
			sqlCode.append(" WHERE ").append(where.toString());
		}
		sqlCode.append(';');

		return statement.executeUpdate(sqlCode.toString(), Statement.RETURN_GENERATED_KEYS);
	}

	protected int insert(Object... values) throws SQLException
	{
		if(!canPerformOp(tableName) || values.length == 0)
		{
			return 0;
		}

		StringBuilder valueString = new StringBuilder();
		int i = 0;
		while(i < values.length - 1)
		{
			valueString.append(DAOUtils.valueToString(values[i])).append(',');
			i++;
		}
		valueString.append(DAOUtils.valueToString(values[i]));

		return statement.executeUpdate(String.format("INSERT INTO `%s` VALUES (%s);", tableName, valueString.toString()), Statement.RETURN_GENERATED_KEYS);
	}

	protected int delete(DAOWhereBuilder where) throws SQLException
	{
		if(where == null)
		{
			return 0;
		}

		return statement.executeUpdate(String.format("DELETE FROM `%s` WHERE %s;", tableName, where.getText()), Statement.RETURN_GENERATED_KEYS);
	}

	private boolean canPerformOp(String tableName) throws SQLException
	{
		return statement != null && !statement.isClosed();
	}

	protected abstract Object generateObjectFromResultSet(ResultSet rs) throws SQLException;

	protected ResultSet getGeneratedKeys() throws SQLException
	{
		return statement.getGeneratedKeys();
	}
}