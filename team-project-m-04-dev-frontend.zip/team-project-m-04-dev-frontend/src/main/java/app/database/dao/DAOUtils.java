package app.database.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

public class DAOUtils
{
	/**
	 * Converts a java object to how it's value would be written in SQL.
	 * @param value
	 * @return
	 */
	public static String valueToString(Object value)
	{
		if(value == null)
		{
			return "NULL";
		}
		if(value instanceof Boolean)
		{
			return (Boolean)value ? "TRUE" : "FALSE";
		}
		if(value instanceof String)
		{
			return String.format("\'%s\'", value.toString());
		}
		return value.toString();
	}

	public static Integer getInteger(ResultSet rs, String columnLabel) throws SQLException
	{
		int value = rs.getInt(columnLabel);
		return rs.wasNull() ? null : value;
	}
}
