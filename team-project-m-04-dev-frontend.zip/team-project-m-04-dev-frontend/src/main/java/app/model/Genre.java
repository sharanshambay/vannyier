package app.model;

public enum Genre
{
	Action,
	Adventure
}