package app.database;

import java.sql.*;

public class Database
{
	private Connection connection;
	private String name;

	public Database(String name)
	{
		this.name = name;
		establishConnection();
	}

	private void establishConnection()
	{
		String url = String.format("jdbc:mysql://localhost:3306/%s?allowPublicKeyRetrieval=true&useSSL=false&serverTimezone=UTC", name);
		try
		{
			connection = DriverManager.getConnection(url, "root", "password");
		}
		catch (SQLException e)
		{
			e.printStackTrace();
		}
	}

	public void close() throws SQLException
	{
		connection.close();
	}

	public boolean isConnected()
	{
		return connection != null;
	}

	public Connection getConnection()
	{
		return connection;
	}

	public Statement createStatement() throws SQLException
	{
		return connection.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
	}
}